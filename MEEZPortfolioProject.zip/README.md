# MEEZ_Portfolio_Project
Today 19_07_2023 I'm going to start my own personal website project let's see what much time it'll take. Also soon I'm going to start social media presence
